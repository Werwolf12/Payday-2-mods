local old_init = WeaponTweakData.init
function WeaponTweakData:init(tweak_data)
old_init(self, tweak_data)
self.deagle.stats_modifiers = {damage = 1000}
self.deagle.stats.damage = 160
self.deagle.can_shoot_through_enemy = true
self.deagle.can_shoot_through_wall = true
self.deagle.can_shoot_through_shield = true
self.deagle.armor_piercing_chance = 100
end
