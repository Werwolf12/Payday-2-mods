local old_init = WeaponTweakData.init
function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)
-- Better Saws
self.saw_secondary.CLIP_AMMO_MAX = 150
self.saw_secondary.AMMO_MAX = 450
self.saw_secondary.AMMO_PICKUP = {.1,.2}
self.saw.CLIP_AMMO_MAX = 150
self.saw.AMMO_MAX = 450
self.saw.AMMO_PICKUP = {.1,.2}
self.saw.stats.damage = 50
self.saw_secondary.stats.damage = 50
--Better MP40
self.erma.AMMO_PICKUP = {4,10}
--Better RPG & C101	
self.rpg7.AMMO_MAX = 7
self.rpg7.AMMO_PICKUP = {0.01,0.5}
self.ray.AMMO_MAX = 16
self.ray.AMMO_PICKUP = {0.1,5}
--Better Galant
self.ching.AMMO_MAX = 100
--Better Miniguns
self.m134.stats.damage = 50
self.m134.can_shoot_through_enemy = true
self.m134.can_shoot_through_shield = true
self.m134.armor_piercing_chance = 30
self.shuno.stats.damage = 75
self.shuno.can_shoot_through_enemy = true
self.shuno.can_shoot_through_shield = true
self.shuno.armor_piercing_chance = 25
--Better Little Friend
self.contraband.AMMO_MAX = 160
self.contraband.stats.damage = 160
self.contraband.FIRE_MODE = "auto"
self.contraband.stats.recoil = 12
self.contraband.AMMO_PICKUP = {0.95, 3.00}
self.contraband_m203.AMMO_PICKUP = {0.15, 0.55}
self.contraband_m203.AMMO_MAX = 5
--Tweaked Deagles
self.x_deagle.AMMO_MAX = 42
self.x_deagle.CLIP_AMMO_MAX = 14
self.x_deagle.stats.damage = 150
self.x_deagle.armor_piercing_chance = 20
self.x_deagle.can_shoot_through_enemy = true
self.x_deagle.can_shoot_through_shield = true
self.deagle.CLIP_AMMO_MAX = 7
self.deagle.AMMO_MAX = 21	
self.deagle.stats.damage = 150
self.deagle.armor_piercing_chance = 10
self.deagle.can_shoot_through_enemy = true
self.deagle.can_shoot_through_shield = true
end
